/* DevTrack — client-side productivity dashboard.
 * Public GitHub data is fetched from api.github.com without a token.
 * Tasks, projects and manually logged coding activity stay in this browser.
 */
(() => {
  "use strict";

  const STORAGE_KEY = "devtrack.v1";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const todayKey = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };
  const dateKey = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const validURL = value => {
    try { const url = new URL(value); return ["http:", "https:"].includes(url.protocol) ? url.href : ""; }
    catch { return ""; }
  };
  const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
  const blankState = () => ({ profile: { name: "Developer", github: "" }, tasks: [], projects: [], activity: {}, githubCache: null });

  function loadState() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!parsed || typeof parsed !== "object") return blankState();
      return {
        ...blankState(), ...parsed,
        profile: { ...blankState().profile, ...(parsed.profile || {}) },
        tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
        projects: Array.isArray(parsed.projects) ? parsed.projects : [],
        activity: parsed.activity && typeof parsed.activity === "object" ? parsed.activity : {}
      };
    } catch { return blankState(); }
  }
  let state = loadState();
  let githubBusy = false;
  let showAllTasks = false;

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch {
      toast("Could not save. Browser storage may be full or disabled.", "error");
      return false;
    }
  }
  function toast(message, type = "") {
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    node.textContent = message;
    $("#toast-region").append(node);
    window.setTimeout(() => node.remove(), 3400);
  }
  function formatDate(value) {
    if (!value) return "No due date";
    const date = new Date(`${value}T12:00:00`);
    if (Number.isNaN(date.getTime())) return "No due date";
    return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  }
  function getStreak() {
    const days = new Set(Object.keys(state.activity).filter(key => Number(state.activity[key]) > 0));
    let cursor = new Date();
    if (!days.has(dateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
    let count = 0;
    while (days.has(dateKey(cursor))) {
      count++;
      cursor.setDate(cursor.getDate() - 1);
      if (count > 4000) break;
    }
    return count;
  }
  function countCompletedThisWeek() {
    const now = new Date();
    const monday = new Date(now);
    monday.setHours(0,0,0,0);
    monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    const nextMonday = new Date(monday);
    nextMonday.setDate(monday.getDate() + 7);
    return state.tasks.filter(task => task.completedAt && new Date(`${task.completedAt}T12:00:00`) >= monday && new Date(`${task.completedAt}T12:00:00`) < nextMonday).length;
  }
  function render() {
    renderProfile();
    renderStats();
    renderHeatmap();
    renderWeeklyChart();
    renderTasks();
    renderProjects();
    renderProjectSelect();
    $("#footer-year").textContent = new Date().getFullYear();
    $("#today-label").textContent = new Date().toLocaleDateString(undefined, { weekday:"long", month:"long", day:"numeric" }).toUpperCase();
    $("#nav-task-count").textContent = state.tasks.filter(task => !task.completed).length;
  }
  function renderProfile() {
    const name = (state.profile.name || "Developer").trim() || "Developer";
    const initial = name.slice(0,1).toUpperCase();
    $("#profile-name").textContent = name;
    $("#profile-avatar").textContent = initial;
    $("#top-avatar").textContent = initial;
    $("#welcome-title").innerHTML = `Make progress, <span class="gradient-text">${escapeHTML(name.split(/\s+/)[0])}.</span>`;
  }
  function renderStats() {
    const completed = state.tasks.filter(task => task.completed).length;
    const remaining = state.tasks.length - completed;
    $("#stat-completed").textContent = completed;
    $("#stat-task-note").textContent = `${remaining} task${remaining === 1 ? "" : "s"} remaining`;
    $("#stat-projects").textContent = state.projects.length;
    const streak = getStreak();
    $("#stat-streak").textContent = streak;
    $("#streak-note").textContent = streak ? "Keep the momentum going" : "Log a session to begin";
    const stars = state.githubCache && Number.isFinite(state.githubCache.stars) ? state.githubCache.stars : null;
    $("#stat-stars").textContent = stars === null ? "—" : stars.toLocaleString();
    $("#stat-github-note").textContent = state.githubCache ? `${state.githubCache.repoCount} public repos` : "Connect a username";
  }
  function renderHeatmap() {
    const container = $("#heatmap");
    container.innerHTML = "";
    const end = new Date();
    end.setHours(0,0,0,0);
    const start = new Date(end);
    start.setDate(start.getDate() - 83);
    start.setDate(start.getDate() - start.getDay());
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < 84; i++) {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      const key = dateKey(date);
      const count = Math.max(0, Math.min(20, Number(state.activity[key]) || 0));
      const level = count === 0 ? 0 : count === 1 ? 1 : count <= 3 ? 2 : count <= 5 ? 3 : 4;
      const cell = document.createElement("button");
      cell.type = "button";
      cell.className = `heat-cell level-${level}`;
      cell.title = `${key}: ${count} coding session${count === 1 ? "" : "s"}`;
      cell.setAttribute("aria-label", cell.title);
      cell.addEventListener("click", () => {
        if (key === todayKey()) logActivity();
        else toast(`${key}: ${count} logged session${count === 1 ? "" : "s"}. You can log activity for today only.`);
      });
      fragment.append(cell);
    }
    container.append(fragment);
    const total = Object.values(state.activity).reduce((sum, value) => sum + Math.max(0, Number(value) || 0), 0);
    $("#activity-total").textContent = `${total} session${total === 1 ? "" : "s"}`;
  }
  function renderWeeklyChart() {
    const chart = $("#weekly-chart");
    chart.innerHTML = "";
    const now = new Date();
    const monday = new Date(now);
    monday.setHours(0,0,0,0);
    monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
    const values = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(monday);
      day.setDate(monday.getDate() + i);
      const key = dateKey(day);
      values.push(state.tasks.filter(task => task.completedAt === key).length);
    }
    const max = Math.max(1, ...values);
    values.forEach((value, index) => {
      const col = document.createElement("div");
      col.className = "chart-column";
      const bar = document.createElement("div");
      bar.className = `chart-bar${dateKey(new Date(monday.getTime() + index * 86400000)) === todayKey() ? " today" : ""}`;
      bar.style.height = `${Math.max(value ? 8 : 3, (value / max) * 100)}%`;
      bar.title = `${["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][index]}: ${value} completed`;
      col.append(bar);
      chart.append(col);
    });
    $("#weekly-count").textContent = values.reduce((sum, value) => sum + value, 0);
    const total = state.tasks.length;
    const completed = state.tasks.filter(task => task.completed).length;
    $("#weekly-percent").textContent = `${total ? Math.round(completed / total * 100) : 0}% overall`;
  }
  function renderTasks() {
    const container = $("#task-preview");
    const tasks = [...state.tasks].sort((a,b) => Number(a.completed) - Number(b.completed) || ({high:0,medium:1,low:2}[a.priority] - {high:0,medium:1,low:2}[b.priority]) || (a.due || "9999").localeCompare(b.due || "9999"));
    const visible = showAllTasks ? tasks : tasks.slice(0, 5);
    const viewButton = $("#view-all-tasks");
    viewButton.textContent = showAllTasks ? "Show less ↑" : "View all ↗";
    if (!visible.length) {
      container.innerHTML = `<div class="empty-state"><strong>Nothing on your list yet</strong>Add a task to turn your next idea into progress.</div>`;
      return;
    }
    container.innerHTML = visible.map(task => {
      const project = state.projects.find(item => item.id === task.projectId);
      return `<div class="task-row">
        <button class="task-check ${task.completed ? "done" : ""}" data-toggle-task="${escapeHTML(task.id)}" aria-label="${task.completed ? "Reopen" : "Complete"} ${escapeHTML(task.title)}">${task.completed ? "✓" : ""}</button>
        <div class="task-main"><div class="task-title ${task.completed ? "done" : ""}">${escapeHTML(task.title)}</div>
          <div class="task-meta"><span class="priority ${escapeHTML(task.priority || "medium")}">${escapeHTML((task.priority || "medium").replace(/^./, c => c.toUpperCase()))}</span><span>${escapeHTML(task.due ? formatDate(task.due) : "No due date")}</span>${project ? `<span>· ${escapeHTML(project.name)}</span>` : ""}</div></div>
        <div class="task-actions"><button class="mini-action" data-edit-task="${escapeHTML(task.id)}" title="Edit task" aria-label="Edit task">✎</button><button class="mini-action" data-delete-task="${escapeHTML(task.id)}" title="Delete task" aria-label="Delete task">×</button></div>
      </div>`;
    }).join("");
  }
  function renderProjects() {
    const container = $("#project-preview");
    if (!state.projects.length) {
      container.innerHTML = `<div class="empty-state"><strong>Your first project goes here</strong>Track what you're building and the tools you're learning.</div>`;
      return;
    }
    container.innerHTML = state.projects.slice(0, 4).map(project => {
      const tags = (project.tech || []).slice(0, 3).map(tech => `<span class="tech-tag">${escapeHTML(tech)}</span>`).join("");
      const url = validURL(project.url || "");
      return `<div class="project-row"><div class="project-symbol">◇</div><div class="project-main"><div class="project-name">${escapeHTML(project.name)}</div><div class="project-description">${escapeHTML(project.description || "Personal project")}</div><div class="tech-tags">${tags}</div></div><div class="project-actions"><button class="mini-action" data-edit-project="${escapeHTML(project.id)}" aria-label="Edit project" title="Edit project">✎</button>${url ? `<a class="project-open" href="${escapeHTML(url)}" target="_blank" rel="noopener noreferrer" aria-label="Open project link">↗</a>` : ""}</div></div>`;
    }).join("");
  }
  function renderProjectSelect(selected = "") {
    const select = $("#task-project");
    const previous = selected || select.value;
    select.innerHTML = `<option value="">No project</option>` + state.projects.map(project => `<option value="${escapeHTML(project.id)}">${escapeHTML(project.name)}</option>`).join("");
    select.value = state.projects.some(project => project.id === previous) ? previous : "";
  }
  function openDialog(id) {
    const dialog = document.getElementById(id);
    if (dialog && typeof dialog.showModal === "function") dialog.showModal();
    else if (dialog) dialog.setAttribute("open", "");
  }
  function closeDialog(id) {
    const dialog = document.getElementById(id);
    if (dialog && typeof dialog.close === "function") dialog.close();
    else if (dialog) dialog.removeAttribute("open");
  }
  function openTaskModal(task = null) {
    $("#task-form").reset();
    $("#task-id").value = task ? task.id : "";
    $("#task-modal-title").textContent = task ? "Edit task" : "Create a task";
    $("#task-title").value = task ? task.title : "";
    $("#task-priority").value = task ? task.priority : "medium";
    $("#task-due").value = task ? task.due || "" : "";
    $("#task-notes").value = task ? task.notes || "" : "";
    renderProjectSelect(task ? task.projectId : "");
    openDialog("task-modal");
    window.setTimeout(() => $("#task-title").focus(), 50);
  }
  function openProjectModal(project = null) {
    $("#project-form").reset();
    $("#project-id").value = project ? project.id : "";
    $("#project-modal-title").textContent = project ? "Edit project" : "Add a project";
    $("#project-name").value = project ? project.name : "";
    $("#project-description").value = project ? project.description || "" : "";
    $("#project-tech").value = project ? (project.tech || []).join(", ") : "";
    $("#project-url").value = project ? project.url || "" : "";
    openDialog("project-modal");
    window.setTimeout(() => $("#project-name").focus(), 50);
  }
  function logActivity() {
    const key = todayKey();
    state.activity[key] = Math.min(20, (Number(state.activity[key]) || 0) + 1);
    saveState();
    render();
    toast("Coding session logged. Keep going!", "success");
  }
  function toggleTask(id) {
    const task = state.tasks.find(item => item.id === id);
    if (!task) return;
    task.completed = !task.completed;
    task.completedAt = task.completed ? todayKey() : "";
    saveState();
    render();
    toast(task.completed ? "Task completed — nice work." : "Task reopened.");
  }
  function deleteTask(id) {
    const task = state.tasks.find(item => item.id === id);
    if (!task) return;
    if (!window.confirm(`Delete task "${task.title}"?`)) return;
    state.tasks = state.tasks.filter(item => item.id !== id);
    saveState(); render(); toast("Task deleted.");
  }
  function deleteProject(id) {
    const project = state.projects.find(item => item.id === id);
    if (!project) return;
    if (!window.confirm(`Delete project "${project.name}"? Related tasks will remain, but lose their project link.`)) return;
    state.projects = state.projects.filter(item => item.id !== id);
    state.tasks.forEach(task => { if (task.projectId === id) task.projectId = ""; });
    saveState(); render(); toast("Project deleted.");
  }
  async function connectGitHub(username) {
    username = String(username || "").trim().replace(/^@/, "");
    if (!username) { toast("Enter a GitHub username first.", "error"); return; }
    if (!/^[a-z\d](?:[a-z\d-]{0,37}[a-z\d])?$/i.test(username)) {
      toast("That doesn't look like a valid GitHub username.", "error"); return;
    }
    if (githubBusy) return;
    githubBusy = true;
    $("#github-connect-btn").disabled = true;
    $("#github-connect-btn").textContent = "Loading…";
    setApiStatus("Loading public data", "");
    $("#github-empty").classList.remove("hidden");
    $("#github-empty").innerHTML = `<div class="empty-glyph">◌</div><strong>Fetching public profile…</strong><p>Contacting GitHub's public API.</p>`;
    $("#github-results").classList.add("hidden");
    try {
      const headers = { "Accept": "application/vnd.github+json" };
      const profileResponse = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}`, { headers });
      if (profileResponse.status === 404) throw new Error("GitHub username not found. Check the spelling and try again.");
      if (profileResponse.status === 403 || profileResponse.status === 429) throw new Error("GitHub API rate limit reached. Wait a little and try again.");
      if (!profileResponse.ok) throw new Error(`GitHub returned an error (${profileResponse.status}). Try again later.`);
      const profile = await profileResponse.json();
      const repos = [];
      // Paginate so aggregate star/fork totals include public repositories beyond page one.
      for (let page = 1; page <= 10; page++) {
        const reposResponse = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}/repos?sort=updated&per_page=100&page=${page}&type=owner`, { headers });
        if (reposResponse.status === 403 || reposResponse.status === 429) throw new Error("GitHub API rate limit reached while loading repositories. Wait a little and try again.");
        if (!reposResponse.ok) throw new Error(`Could not load repositories (${reposResponse.status}).`);
        const pageRepos = await reposResponse.json();
        if (!Array.isArray(pageRepos)) throw new Error("GitHub returned an unexpected repository response.");
        repos.push(...pageRepos);
        if (pageRepos.length < 100) break;
      }
      const stars = repos.reduce((sum, repo) => sum + (Number(repo.stargazers_count) || 0), 0);
      const forks = repos.reduce((sum, repo) => sum + (Number(repo.forks_count) || 0), 0);
      state.profile.github = username;
      state.githubCache = { username, stars, repoCount: profile.public_repos || repos.length, fetchedAt: new Date().toISOString() };
      saveState();
      renderStats();
      $("#settings-github").value = username;
      $("#github-profile").innerHTML = `
        <img class="github-avatar" src="${escapeHTML(validURL(profile.avatar_url) || "")}" alt="" loading="lazy" referrerpolicy="no-referrer">
        <div class="github-user-info"><strong>${escapeHTML(profile.name || profile.login)}</strong><span>@${escapeHTML(profile.login)}${profile.bio ? ` · ${escapeHTML(profile.bio)}` : ""}</span>
          <div class="github-metrics"><span><b>${Number(profile.public_repos || 0).toLocaleString()}</b> repos</span><span><b>${stars.toLocaleString()}</b> stars</span><span><b>${forks.toLocaleString()}</b> forks</span>${profile.followers != null ? `<span><b>${Number(profile.followers).toLocaleString()}</b> followers</span>` : ""}</div></div>
        <a class="github-profile-link" href="${escapeHTML(validURL(profile.html_url))}" target="_blank" rel="noopener noreferrer">Open profile ↗</a>`;
      const visibleRepos = [...repos].filter(repo => !repo.fork).sort((a,b) => new Date(b.updated_at) - new Date(a.updated_at)).slice(0, 6);
      $("#repo-grid").innerHTML = visibleRepos.length ? visibleRepos.map(repo => `
        <article class="repo-card"><a class="repo-name" href="${escapeHTML(validURL(repo.html_url))}" target="_blank" rel="noopener noreferrer">${escapeHTML(repo.name)} ↗</a>
          <p class="repo-description">${escapeHTML(repo.description || "No description added yet.")}</p>
          <div class="repo-meta">${repo.language ? `<span><i class="language-dot"></i>${escapeHTML(repo.language)}</span>` : ""}<span>☆ ${Number(repo.stargazers_count || 0)}</span><span>⑂ ${Number(repo.forks_count || 0)}</span><span>Updated ${escapeHTML(relativeDate(repo.updated_at))}</span></div></article>`).join("") : `<div class="empty-state">No non-fork public repositories found for this account.</div>`;
      $("#github-results").classList.remove("hidden");
      $("#github-empty").classList.add("hidden");
      setApiStatus("Connected", "connected");
      toast(`Loaded public GitHub data for @${profile.login}.`, "success");
    } catch (error) {
      setApiStatus("Connection issue", "error");
      $("#github-results").classList.add("hidden");
      $("#github-empty").classList.remove("hidden");
      $("#github-empty").innerHTML = `<div class="empty-glyph">!</div><strong>Couldn't load GitHub data</strong><p>${escapeHTML(error.message || "Network error. Check your connection and try again.")}</p>`;
      toast(error.message || "Could not connect to GitHub.", "error");
    } finally {
      githubBusy = false;
      $("#github-connect-btn").disabled = false;
      $("#github-connect-btn").textContent = "Connect profile";
    }
  }
  function relativeDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "recently";
    const days = Math.max(0, Math.floor((Date.now() - date.getTime()) / 86400000));
    if (days === 0) return "today";
    if (days === 1) return "1d ago";
    if (days < 30) return `${days}d ago`;
    if (days < 365) return `${Math.floor(days / 30)}mo ago`;
    return `${Math.floor(days / 365)}y ago`;
  }
  function setApiStatus(label, stateClass) {
    const status = $("#api-status");
    status.className = `api-status ${stateClass}`;
    status.innerHTML = `<i></i> ${escapeHTML(label)}`;
  }
  function exportBackup() {
    const blob = new Blob([JSON.stringify({ app: "DevTrack", version: 1, exportedAt: new Date().toISOString(), data: state }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = `devtrack-backup-${todayKey()}.json`;
    document.body.append(anchor); anchor.click(); anchor.remove();
    URL.revokeObjectURL(url);
    toast("Backup exported.", "success");
  }
  async function importBackup(file) {
    if (!file) return;
    try {
      const imported = JSON.parse(await file.text());
      const data = imported.data || imported;
      if (!data || typeof data !== "object" || !Array.isArray(data.tasks) || !Array.isArray(data.projects) || typeof data.activity !== "object") {
        throw new Error("This file doesn't look like a DevTrack backup.");
      }
      if (!window.confirm("Import this backup and replace your current DevTrack data? Export a backup first if you want to keep it.")) return;
      state = {
        ...blankState(), ...data,
        profile: { ...blankState().profile, ...(data.profile || {}) },
        tasks: data.tasks, projects: data.projects,
        activity: data.activity || {}
      };
      saveState(); render();
      $("#github-username").value = state.profile.github || "";
      toast("Backup imported.", "success");
    } catch (error) { toast(error.message || "Could not import that file.", "error"); }
    finally { $("#import-file").value = ""; }
  }
  function wireEvents() {
    $("#log-activity-btn").addEventListener("click", logActivity);
    $("#sidebar-log-btn").addEventListener("click", logActivity);
    $("#heatmap-log").addEventListener("click", logActivity);
    $("#add-task-top").addEventListener("click", () => openTaskModal());
    $("#add-task-inline").addEventListener("click", () => openTaskModal());
    $("#add-project-btn").addEventListener("click", () => openProjectModal());
    $("#view-all-tasks").addEventListener("click", () => {
      if (state.tasks.length <= 5 && !showAllTasks) { toast(state.tasks.length ? "All tasks are already shown." : "No tasks yet. Add one to get started."); return; }
      showAllTasks = !showAllTasks;
      renderTasks();
    });
    $("#settings-btn").addEventListener("click", () => {
      $("#display-name").value = state.profile.name || "";
      $("#settings-github").value = state.profile.github || "";
      openDialog("settings-modal");
    });
    $("#top-avatar").addEventListener("click", () => $("#settings-btn").click());
    $("#github-form").addEventListener("submit", event => {
      event.preventDefault();
      connectGitHub($("#github-username").value);
    });
    $("#task-form").addEventListener("submit", event => {
      event.preventDefault();
      const title = $("#task-title").value.trim();
      if (!title) { toast("Task name is required.", "error"); return; }
      const id = $("#task-id").value;
      const existing = state.tasks.find(task => task.id === id);
      const task = {
        id: id || uid(), title, priority: $("#task-priority").value,
        due: $("#task-due").value, projectId: $("#task-project").value,
        notes: $("#task-notes").value.trim(),
        completed: existing ? existing.completed : false,
        completedAt: existing ? existing.completedAt || "" : "",
        createdAt: existing ? existing.createdAt : todayKey()
      };
      if (existing) state.tasks = state.tasks.map(item => item.id === id ? task : item);
      else state.tasks.unshift(task);
      saveState(); render(); closeDialog("task-modal"); toast(existing ? "Task updated." : "Task created.", "success");
    });
    $("#project-form").addEventListener("submit", event => {
      event.preventDefault();
      const name = $("#project-name").value.trim();
      if (!name) { toast("Project name is required.", "error"); return; }
      const rawURL = $("#project-url").value.trim();
      if (rawURL && !validURL(rawURL)) { toast("Enter a valid http or https project URL.", "error"); return; }
      const id = $("#project-id").value;
      const existing = state.projects.find(project => project.id === id);
      const project = {
        id: id || uid(), name, description: $("#project-description").value.trim(),
        tech: $("#project-tech").value.split(",").map(item => item.trim()).filter(Boolean).slice(0, 8),
        url: rawURL ? validURL(rawURL) : "", createdAt: existing ? existing.createdAt : todayKey()
      };
      if (existing) state.projects = state.projects.map(item => item.id === id ? project : item);
      else state.projects.unshift(project);
      saveState(); render(); closeDialog("project-modal"); toast(existing ? "Project updated." : "Project added.", "success");
    });
    $("#settings-form").addEventListener("submit", event => {
      event.preventDefault();
      state.profile.name = $("#display-name").value.trim() || "Developer";
      state.profile.github = $("#settings-github").value.trim().replace(/^@/, "");
      saveState(); render(); closeDialog("settings-modal"); toast("Settings saved.", "success");
      $("#github-username").value = state.profile.github;
    });
    $("#clear-data-btn").addEventListener("click", () => {
      if (!window.confirm("Permanently clear all tasks, projects, coding activity, and profile settings from this browser? Export a backup first if needed.")) return;
      state = blankState(); saveState(); render(); $("#github-username").value = ""; $("#github-results").classList.add("hidden"); $("#github-empty").classList.remove("hidden"); $("#github-empty").innerHTML = `<div class="empty-glyph">⌘</div><strong>Your GitHub, at a glance</strong><p>Enter your username to load public repositories, stars, forks, and primary languages.</p>`; setApiStatus("Not connected", ""); closeDialog("settings-modal"); toast("Local DevTrack data cleared.");
    });
    $("#export-btn").addEventListener("click", exportBackup);
    $("#import-backup-btn").addEventListener("click", () => $("#import-file").click());
    $("#export-btn").addEventListener("contextmenu", event => { event.preventDefault(); $("#import-file").click(); });
    $("#import-file").addEventListener("change", event => importBackup(event.target.files[0]));
    $$("[data-close]").forEach(button => button.addEventListener("click", () => closeDialog(button.dataset.close)));
    ["task-modal","project-modal","settings-modal"].forEach(id => {
      const dialog = document.getElementById(id);
      dialog.addEventListener("click", event => { if (event.target === dialog) closeDialog(id); });
    });
    $("#task-preview").addEventListener("click", event => {
      const toggle = event.target.closest("[data-toggle-task]");
      const edit = event.target.closest("[data-edit-task]");
      const del = event.target.closest("[data-delete-task]");
      if (toggle) toggleTask(toggle.dataset.toggleTask);
      if (edit) openTaskModal(state.tasks.find(task => task.id === edit.dataset.editTask));
      if (del) deleteTask(del.dataset.deleteTask);
    });
    $("#project-preview").addEventListener("click", event => {
      const edit = event.target.closest("[data-edit-project]");
      if (edit) openProjectModal(state.projects.find(project => project.id === edit.dataset.editProject));
    });
    $("#menu-toggle").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
    $$(".nav-link").forEach(link => link.addEventListener("click", () => {
      $$(".nav-link").forEach(item => item.classList.toggle("active", item === link));
      $("#page-name").textContent = link.textContent.trim().replace(/\s+\d+$/, "");
      $("#sidebar").classList.remove("open");
    }));
    document.addEventListener("keydown", event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault(); openTaskModal();
      }
    });
  }

  function init() {
    wireEvents();
    render();
    $("#github-username").value = state.profile.github || "";
    if (state.profile.github) connectGitHub(state.profile.github);
    // Export is available from the top bar; import is available in Workspace settings.
    $("#export-btn").setAttribute("title", "Export JSON backup");
  }
  init();
})();